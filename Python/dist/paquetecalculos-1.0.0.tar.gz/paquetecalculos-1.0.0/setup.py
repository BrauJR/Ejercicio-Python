from setuptools import setup

setup(
	name="paquetecalculos",
	version="1.0.0",
	description="Paquete de redondeo y potencia",
	author="Brau",
	author_email="jrm4912@gmail.com",
	package=["calculos","calculos.redo_pote"]
	)